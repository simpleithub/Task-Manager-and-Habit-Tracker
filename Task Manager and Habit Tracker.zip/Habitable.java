package com.taskmanager;

public interface Habitable {
    void markAsCompleted();
    int getStreak();
}